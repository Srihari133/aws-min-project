---
title: "テンプレート"
weight: 10
---

![stack-png](/static/intermediate/templates/stack.png)
