---
title: "Operations"
weight: 20
---

![stack-png](/static/intermediate/templates/stack.png)
