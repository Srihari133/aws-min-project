---
title: "AWS CloudFormation ワークショップ"
weight: 1
---

![aws-cloudformation](/static/aws-cloudformation.png)

#### AWS CloudFormation ワークショップへようこそ !

このワークショップは、ビルダーの方が [AWS CloudFormation](https://aws.amazon.com/cloudformation/) の特徴を学び、素早く構築を開始することを目的としています。

CloudFormation、コマンドライン、Git、開発ワークフローに関する経験は不要です。
